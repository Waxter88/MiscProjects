# Mind Optimizers - Emmas Engines

Live Website: https://mindoptimizers.azurewebsites.net/

# Logins

Password for all accounts is: Pa55w@rd

Admin:
               
EmmaH@outlook.com       <br/>
EmilyA@outlook.com      <br/>
admin@outlook.com      

Order/Purchase:
                
samK@outlook.com     

Sales:

wendyB@outlook.com      <br/>
williamT@outlook.com    <br/>
staff@outlook.com       
