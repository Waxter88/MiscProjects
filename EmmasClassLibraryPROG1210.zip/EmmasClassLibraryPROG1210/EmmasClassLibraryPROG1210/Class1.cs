﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmmasClassLibraryPROG1210
{
    public class Class1
    {
    }
}
