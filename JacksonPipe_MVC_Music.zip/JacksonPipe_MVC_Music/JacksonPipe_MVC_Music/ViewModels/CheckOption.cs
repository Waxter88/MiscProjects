﻿namespace JacksonPipe_MVC_Music.ViewModels
{
    public class CheckOption
    {
        public int ID { get; set; }
        public string DisplayText { get; set; }
        public bool Assigned { get; set; }
    }
}
