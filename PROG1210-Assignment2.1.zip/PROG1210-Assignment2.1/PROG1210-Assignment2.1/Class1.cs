﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG1210_Assignment2._1
{
    public class Class1
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
    }
}
