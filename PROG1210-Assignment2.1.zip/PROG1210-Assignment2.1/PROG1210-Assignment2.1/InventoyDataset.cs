﻿namespace PROG1210_Assignment2._1
{
}

namespace PROG1210_Assignment2._1 {
    
    
    public partial class InventoyDataset {
    }
}
