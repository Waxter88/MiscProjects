﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG1210_Assignment4_ClassLibrary
{
    public class Class1
    {
    }
}
